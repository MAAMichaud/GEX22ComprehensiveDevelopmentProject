

# zombie notes

### JSON Parser 

[Json for modern C++ ]([JSON for Modern C++ - JSON for Modern C++ (nlohmann.me)](https://json.nlohmann.me/)) is a Jason parser for C++11 and beyond. It lets you you json like an STL container. The git hub repository is nlohmann/json. 

